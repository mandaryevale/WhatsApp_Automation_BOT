package tests;

 



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import org.apache.log4j.Logger;



import org.openqa.selenium.JavascriptExecutor;



/*
public class Project 
{
	@Test
	public void whatsapp_web() throws InterruptedException
	{
		 // Set updated ChromeDriver version 
		ChromeOptions co = new ChromeOptions();
		
		 // Create an instance/object of ChromeDriver
		co.setBrowserVersion("130.0.6723.69");
		
		
		WebDriver driver = new ChromeDriver(co);
		 //hold browser some seconds
		
		//Maximize window  
		driver.manage().window().maximize();
		
		// Navigate to a website
		driver.get("https://www.amazon.in/");
		
		Thread.sleep(1000);
		
		// Capture the title of the page
        String  pageTitle = driver.getTitle();
        
        // Print the title to the console
        System.out.println("Title of the Amazon home page is : " + pageTitle);

		Thread.sleep(1000);
        
        // Locate the Amazon Logo
        WebElement amazonLogo = driver.findElement(By.id("nav-logo-sprites"));

        if (amazonLogo.isDisplayed()) 
        {
            System.out.println("Amazon logo is displayed on the home page.");
        } 
        else 
        {
            System.out.println("Amazon logo is not displayed on the page.");
        }

		Thread.sleep(1000);
        
        //Click on Mobile categeory link on home page
        driver.findElement(By.linkText("Mobiles")).click(); 

		Thread.sleep(1000);
        
        //print message on console
        System.out.println("Click on Mobiles category on homepage.");
        
        Thread.sleep(1000); 
  
        
        
        //scroll down to specific image
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1500)", ""); //value '400' can be altered
        
        //windowdown 
        System.out.println("Window scrolldown successfully");
        Thread.sleep(1000);
        
        
        //Click on Mobile categeory link on home page
        driver.findElement(By.xpath("//img[@alt='iphone13']")).click(); 
        Thread.sleep(1000);
        
        
        //scroll down to specific image
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)", ""); //value '400' can be altered
        Thread.sleep(1000);
        
		//close browser
        driver.quit();
	}	
}

*/



public class Project  
{   
	
	 private static final Logger logger = Logger.getLogger(Project.class);

	@Test
	public void whatsapp_web() throws InterruptedException
	{
   
   
    
    	 // Set updated ChromeDriver version 
		ChromeOptions co = new ChromeOptions();
		
		 // Create an instance/object of ChromeDriver
		co.setBrowserVersion("130.0.6723.69");
		
		
		WebDriver driver = new ChromeDriver(co); 
		logger.info("1. Driver initialized.");

        try {
        	
    		
    		//Maximize window  
    		driver.manage().window().maximize();
    		logger.info("2. maximize window");
    		
    		// Navigate to a website
    		driver.get("https://www.amazon.in/");
    		logger.info("3. Navigated to amazon.com");
    		
    		Thread.sleep(1000);
    		
    		// Capture the title of the page
            String  pageTitle = driver.getTitle();
        	logger.info("4. Title is captured");
            
            // Print the title of amazon home page to the console
        	logger.debug("5. Title of the Amazon home page is : " + pageTitle);
        	
    		Thread.sleep(1000);
            
            // Locate the Amazon Logo
            WebElement amazonLogo = driver.findElement(By.id("nav-logo-sprites"));
        	logger.info("6. logo finds correctly");

            if (amazonLogo.isDisplayed()) 
            {
                //System.out.println("Amazon logo is displayed on the home page.");
                logger.info("7. Amazon logo is displayed on the home page");
            } 
            else 
            {
               // System.out.println("Amazon logo is not displayed on the page.");
                logger.info("8. Amazon logo is not displayed on the home page");
            }

    		Thread.sleep(1000);
            
            //Click on Mobile categeory link on home page
            driver.findElement(By.linkText("Mobiles")).click(); 
            logger.info("9. successfully clicked on 'Mobiles' menu ");
            

    		Thread.sleep(1000);
            
            //print message on console
         //   System.out.println("Click on Mobiles category on homepage.");
            
            Thread.sleep(1000); 
      
            
            
            //scroll down to specific image
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1500)", ""); //value '400' can be altered
            
            //windowdown 
         //   System.out.println("Window scrolldown successfully");
            logger.info("10. Window scrolldown successfully");
            Thread.sleep(1000);
            
            
            //Click on Mobile categeory link on home page
            driver.findElement(By.xpath("//img[@alt='iphone13']")).click(); 
            logger.info("11. successfully clicked on one item on PLP");
            Thread.sleep(1000);
            
            
            //scroll down to specific image
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)", ""); //value '400' can be altered
            logger.info("12. Window scrolldown successfully as see ATC button");
            Thread.sleep(1000);
            

        } 
        catch (Exception e) 
        {
            logger.error("An error occurred: ", e);
        } finally {
            driver.quit();
            logger.info("13. Driver closed.");
      }
    }
}

 