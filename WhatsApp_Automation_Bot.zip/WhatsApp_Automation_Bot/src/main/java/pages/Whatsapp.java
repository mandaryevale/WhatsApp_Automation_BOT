package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Whatsapp 
{
	WebDriver driver;
	public Whatsapp (WebDriver driver)
	{
		this.driver=driver;
	}
	By ContactName1= By.xpath("//span[@title='Akash Yevale']");
	By ContactName2= By.xpath("//span[@title='Pavan']");
	By ContactName3= By.xpath("//span[@title='Sagar BCA 2']");
	By ContactName4= By.xpath("//span[@title='Omkar Bhise']");
	By ContactName5= By.xpath("//span[@title='Raj More']");
	
	
	
	
//	By AddToCart= By.xpath("//button[contains(@class,'_2KpZ6l _2U9uOA _3v1-ww')]");
//	By BuyNow= By.xpath("//button[contains(@class,'_2KpZ6l _2U9uOA ihZ75k _3AWRsL')]");
//	By RatingAndReviews= By.xpath("//div[contains(@class,'_3_L3jD')]");
//	By FlipkartAssured= By.xpath("//span[contains(@class,'b7864- _2Z07dN')]");
//	By Compare= By.xpath("//div[contains(@class,'_3PzNI- _3EPyR5')]");
//	By Share= By.xpath("//span[contains(@class,'_2kXMeX')]");
	
	public void FirstContact() 
	{
		driver.findElement(ContactName1).click();	
	}	
	
}